from flask import Flask, request, jsonify
import psycopg2
from elasticsearch import Elasticsearch
from psycopg2.extras import RealDictCursor

app = Flask(__name__)

# Initialize Elasticsearch client
es = Elasticsearch([{'host': 'localhost', 'port': 9200, 'scheme': 'http'}])

# Elasticsearch index name
index_name = 'documents'

# PostgreSQL database connection parameters
db_params = {
    'dbname': 'mock_json_db',
    'user': 'postgres',
    'password': '0125',
    'host': 'localhost',
    'port': '5432'
}

# Helper function to get a PostgreSQL connection
def get_db_connection():
    conn = psycopg2.connect(**db_params)
    return conn

# POST /document (Save document)
@app.route('/document', methods=['POST'])
def add_document():
    data = request.json
    document = data.get('document')

    if not document or 'title' not in document or 'content' not in document:
        return jsonify({"error": "Both 'title' and 'content' are required"}), 400

    title = document['title']
    content = document['content']

    try:
        # Insert document into PostgreSQL
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO documents (title, content) VALUES (%s, %s) RETURNING id",
            (title, content)
        )
        doc_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        conn.close()

        # Index the document into Elasticsearch
        es.index(index=index_name, id=doc_id, body={'title': title, 'content': content})

        return jsonify({
            "document": {
                "id": doc_id,
                "title": title,
                "content": content
            }
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# GET /search (Search documents by substring)
@app.route('/search', methods=['GET'])
def search_document():
    query = request.args.get('query')
    if not query:
        return jsonify({"error": "Query parameter is required"}), 400

    try:
        # Perform search in Elasticsearch
        results = es.search(index=index_name, body={
            "query": {
                "multi_match": {
                    "query": query,
                    "fields": ["title^2", "content"]  # Boost title field priority
                }
            }
        })
        hits = results['hits']['hits']

        # Prepare search response based on where the substring was found
        search_results = []
        for hit in hits:
            if query.lower() in hit['_source']['title'].lower():
                search_results.append({
                    "id": hit['_id'],
                    "fieldName": 'title',
                    "fieldContent": hit['_source']['title']
                })
            if query.lower() in hit['_source']['content'].lower():
                search_results.append({
                    "id": hit['_id'],
                    "fieldName": 'content',
                    "fieldContent": hit['_source']['content']
                })

        return jsonify({"documents": search_results}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# PATCH /document (Patch a document)
@app.route('/document', methods=['PATCH'])
def edit_document():
    data = request.json
    document_id = data.get('documentId')
    document = data.get('document')

    if not document_id or not document or 'title' not in document or 'content' not in document:
        return jsonify({"error": "'documentId', 'title' and 'content' are required"}), 400

    title = document['title']
    content = document['content']

    try:
        # Update document in PostgreSQL
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "UPDATE documents SET title = %s, content = %s WHERE id = %s RETURNING id",
            (title, content, document_id)
        )
        if cur.rowcount == 0:
            return jsonify({"error": f"Document with ID {document_id} not found"}), 404

        conn.commit()
        cur.close()
        conn.close()

        # Update the document in Elasticsearch
        es.index(index=index_name, id=document_id, body={'title': title, 'content': content})

        return jsonify({
            "document": {
                "id": document_id,
                "title": title,
                "content": content
            }
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
